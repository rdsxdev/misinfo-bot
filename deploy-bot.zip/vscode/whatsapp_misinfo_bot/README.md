# WhatsApp Misinformation Detection Bot

A FastAPI-based bot that analyzes WhatsApp messages for misinformation and scam patterns using AI and heuristic analysis.

## Features

-  **Scam Detection**: Identifies common scam keywords and suspicious URLs
-  **AI Analysis**: Uses OpenAI GPT to provide detailed fact-checking
-  **WhatsApp Integration**: Receives and responds to messages via Twilio
-  **Image Analysis**: OCR text extraction from images using Tesseract  
-  **Data Storage**: Logs analysis results to Google Cloud Firestore
-  **Multi-language**: Supports Hindi and English language detection

## Project Structure

```
whatsapp_misinfo_bot/
├── deploy-bot/
│   ├── main.py              # Main FastAPI application
│   ├── Dockerfile           # Docker container configuration
│   ├── requirements.txt     # Python dependencies
│   └── .gcloudignore       # Google Cloud deployment ignore rules
├── .env.example            # Environment variables template
├── .gitignore              # Git ignore rules
└── README.md               # This file
```

## Setup Instructions

### 1. Environment Variables

Copy `.env.example` to `.env` and fill in your actual values:

```bash
cp .env.example .env
```

Required environment variables:

- **TWILIO_ACCOUNT_SID**: Your Twilio Account SID
- **TWILIO_AUTH_TOKEN**: Your Twilio Auth Token  
- **TWILIO_WHATSAPP_NUMBER**: Your Twilio WhatsApp sandbox number
- **GOOGLE_APPLICATION_CREDENTIALS**: Path to your Google Cloud service account key
- **GOOGLE_CLOUD_PROJECT**: Your Google Cloud Project ID
- **OPENAI_API_KEY**: Your OpenAI API key

### 2. Prerequisites

1. **Twilio Account**: Set up WhatsApp sandbox at [Twilio Console](https://console.twilio.com/)
2. **Google Cloud Project**: Enable Firestore API and create service account
3. **OpenAI Account**: Get API key from [OpenAI Platform](https://platform.openai.com/)

## Deployment Options

### Option 1: Google Cloud Run (Recommended)

1. Install Google Cloud CLI:
```bash
curl -O https://dl.google.com/dl/cloudsdk/channels/rapid/downloads/google-cloud-cli-linux-x86_64.tar.gz
tar -xf google-cloud-cli-linux-x86_64.tar.gz
./google-cloud-sdk/install.sh
```

2. Authenticate and set project:
```bash
gcloud auth login
gcloud config set project YOUR_PROJECT_ID
```

3. Deploy from the deploy-bot directory:
```bash
cd deploy-bot
gcloud run deploy whatsapp-bot --source . --region us-central1 --allow-unauthenticated
```

4. Set environment variables in Google Cloud Console or via CLI:
```bash
gcloud run services update whatsapp-bot --region us-central1 \
  --set-env-vars TWILIO_ACCOUNT_SID=your_sid,TWILIO_AUTH_TOKEN=your_token,TWILIO_WHATSAPP_NUMBER=your_number,GOOGLE_CLOUD_PROJECT=your_project,OPENAI_API_KEY=your_key
```

### Option 2: Railway

1. Connect your GitHub repo to Railway
2. Set environment variables in Railway dashboard
3. Deploy directly from the `deploy-bot` directory

### Option 3: Render

1. Connect GitHub repo to Render
2. Set build command: `pip install -r requirements.txt`
3. Set start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
4. Add environment variables in Render dashboard

### Option 4: Docker

1. Build the image:
```bash
cd deploy-bot
docker build -t whatsapp-bot .
```

2. Run with environment variables:
```bash
docker run -p 8080:8080 --env-file ../.env whatsapp-bot
```

## Setting Up Webhook

After deployment, configure your Twilio WhatsApp webhook URL:
1. Go to [Twilio Console > WhatsApp > Sandbox](https://console.twilio.com/us1/develop/sms/settings/whatsapp-sandbox)
2. Set webhook URL to: `https://your-deployed-url.com/webhook`
3. Set HTTP method to POST

## Security Features

- ✅ Environment variables excluded from version control
- ✅ Google Cloud credentials properly managed
- ✅ Phone numbers hashed in logs for privacy
- ✅ Input validation and sanitization
- ✅ Secure API endpoints

## API Endpoints

- `POST /webhook` - Receives WhatsApp messages from Twilio
- `GET /health` - Health check endpoint
- `GET /` - Root endpoint status

## Development

### Local Development

1. Create virtual environment:
```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
cd deploy-bot
pip install -r requirements.txt
```

3. Install Tesseract:
```bash
# Ubuntu/Debian
sudo apt-get install tesseract-ocr

# macOS
brew install tesseract

# Fedora/RHEL
sudo dnf install tesseract
```

4. Run locally:
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8080
```

### Testing

Test the webhook locally using ngrok:
```bash
# Install ngrok and expose local port
ngrok http 8080

# Use the ngrok URL as your Twilio webhook
```

## GitHub Deployment (Secure)

### Setting up GitHub Repository

1. **Initialize Git** (if not already done):
```bash
git init
git add .
git commit -m "Initial commit with secure deployment setup"
```

2. **Create GitHub Repository**:
   - Go to GitHub and create a new repository
   - Don't initialize with README (we already have one)

3. **Add remote and push**:
```bash
git remote add origin https://github.com/yourusername/whatsapp-misinfo-bot.git
git branch -M main
git push -u origin main
```

### Environment Variables Security

Your `.env` file is automatically excluded from GitHub thanks to `.gitignore`. For deployment:

**For GitHub Actions/CI-CD:**
1. Go to your repo Settings > Secrets and Variables > Actions
2. Add these secrets:
   - `TWILIO_ACCOUNT_SID`
   - `TWILIO_AUTH_TOKEN`
   - `TWILIO_WHATSAPP_NUMBER`
   - `GOOGLE_CLOUD_PROJECT`
   - `OPENAI_API_KEY`
   - `GOOGLE_APPLICATION_CREDENTIALS` (base64 encoded JSON)

**For Platform Deployments:**
- **Railway**: Add env vars in project settings
- **Render**: Add env vars in service settings  
- **Google Cloud Run**: Use `gcloud run services update` or Console
- **Heroku**: Use `heroku config:set`

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For issues and questions:
1. Check existing GitHub issues
2. Create a new issue with detailed information
3. Include logs and error messages when reporting bugs

---

**⚠️ Important Security Notes:**
- Never commit `.env` files or API keys to version control
- Use environment variables for all sensitive configuration
- Regularly rotate API keys and tokens
- Monitor usage and costs for cloud services

